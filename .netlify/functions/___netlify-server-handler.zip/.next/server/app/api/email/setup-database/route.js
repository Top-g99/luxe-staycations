(()=>{var a={};a.id=3962,a.ids=[3962,8908],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34115:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>K,patchFetch:()=>J,routeModule:()=>F,serverHooks:()=>I,workAsyncStorage:()=>G,workUnitAsyncStorage:()=>H});var d={};c.r(d),c.d(d,{GET:()=>D,POST:()=>E});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(88908);async function w(){let a={success:!0,message:"Email database setup completed",tablesCreated:[],errors:[]};if(!v.supabase)return a.success=!1,a.message="Supabase client not initialized",a.errors.push("Supabase client not available"),a;try{await x(),a.tablesCreated.push("email_configurations"),await y(),a.tablesCreated.push("email_templates"),await z(),a.tablesCreated.push("email_triggers"),await A(),a.tablesCreated.push("email_logs"),console.log("Email database setup completed successfully")}catch(b){a.success=!1,a.message="Error setting up email database",a.errors.push(b instanceof Error?b.message:"Unknown error"),console.error("Error setting up email database:",b)}return a}async function x(){if(!v.supabase)return;let{error:a}=await v.supabase.rpc("create_email_configurations_table");a&&console.log("Email configurations table may already exist or error occurred:",a)}async function y(){if(!v.supabase)return;let{error:a}=await v.supabase.rpc("create_email_templates_table");a&&console.log("Email templates table may already exist or error occurred:",a)}async function z(){if(!v.supabase)return;let{error:a}=await v.supabase.rpc("create_email_triggers_table");a&&console.log("Email triggers table may already exist or error occurred:",a)}async function A(){if(!v.supabase)return;let{error:a}=await v.supabase.rpc("create_email_logs_table");a&&console.log("Email logs table may already exist or error occurred:",a)}let B=`
-- Email Configurations Table
CREATE TABLE IF NOT EXISTS email_configurations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  smtp_host TEXT NOT NULL,
  smtp_port INTEGER NOT NULL DEFAULT 587,
  smtp_user TEXT NOT NULL,
  smtp_password TEXT NOT NULL,
  enable_ssl BOOLEAN NOT NULL DEFAULT false,
  from_name TEXT NOT NULL,
  from_email TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email Templates Table
CREATE TABLE IF NOT EXISTS email_templates (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  subject TEXT NOT NULL,
  html_content TEXT NOT NULL,
  text_content TEXT,
  variables TEXT[] DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email Triggers Table
CREATE TABLE IF NOT EXISTS email_triggers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  event_type TEXT NOT NULL,
  template_id UUID REFERENCES email_templates(id) ON DELETE CASCADE,
  conditions JSONB DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Email Logs Table
CREATE TABLE IF NOT EXISTS email_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  template_id UUID REFERENCES email_templates(id) ON DELETE SET NULL,
  recipient_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('sent', 'failed', 'pending')),
  error_message TEXT,
  sent_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Bookings Table (if not exists)
CREATE TABLE IF NOT EXISTS bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  property_id TEXT NOT NULL,
  guest_name TEXT NOT NULL,
  guest_email TEXT NOT NULL,
  guest_phone TEXT,
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  guests INTEGER NOT NULL DEFAULT 1,
  total_amount DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  special_requests TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_email_templates_type ON email_templates(type);
CREATE INDEX IF NOT EXISTS idx_email_templates_active ON email_templates(is_active);
CREATE INDEX IF NOT EXISTS idx_email_triggers_event_type ON email_triggers(event_type);
CREATE INDEX IF NOT EXISTS idx_email_triggers_active ON email_triggers(is_active);
CREATE INDEX IF NOT EXISTS idx_email_logs_recipient ON email_logs(recipient_email);
CREATE INDEX IF NOT EXISTS idx_email_logs_status ON email_logs(status);
CREATE INDEX IF NOT EXISTS idx_email_logs_sent_at ON email_logs(sent_at);

-- Bookings indexes
CREATE INDEX IF NOT EXISTS idx_bookings_property_id ON bookings(property_id);
CREATE INDEX IF NOT EXISTS idx_bookings_guest_email ON bookings(guest_email);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_payment_status ON bookings(payment_status);
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);
CREATE INDEX IF NOT EXISTS idx_bookings_check_in ON bookings(check_in);
CREATE INDEX IF NOT EXISTS idx_bookings_check_out ON bookings(check_out);

-- Enable Row Level Security (RLS)
ALTER TABLE email_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_triggers ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (adjust as needed for your security requirements)
CREATE POLICY "Allow public read access to email_templates" ON email_templates FOR SELECT USING (true);
CREATE POLICY "Allow public read access to email_configurations" ON email_configurations FOR SELECT USING (true);
CREATE POLICY "Allow public read access to email_triggers" ON email_triggers FOR SELECT USING (true);
CREATE POLICY "Allow public read access to email_logs" ON email_logs FOR SELECT USING (true);

CREATE POLICY "Allow public insert access to email_templates" ON email_templates FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert access to email_configurations" ON email_configurations FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert access to email_triggers" ON email_triggers FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert access to email_logs" ON email_logs FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access to email_templates" ON email_templates FOR UPDATE USING (true);
CREATE POLICY "Allow public update access to email_configurations" ON email_configurations FOR UPDATE USING (true);
CREATE POLICY "Allow public update access to email_triggers" ON email_triggers FOR UPDATE USING (true);

CREATE POLICY "Allow public delete access to email_templates" ON email_templates FOR DELETE USING (true);
CREATE POLICY "Allow public delete access to email_configurations" ON email_configurations FOR DELETE USING (true);
CREATE POLICY "Allow public delete access to email_triggers" ON email_triggers FOR DELETE USING (true);
CREATE POLICY "Allow public delete access to email_logs" ON email_logs FOR DELETE USING (true);

-- Bookings policies
CREATE POLICY "Allow public read access to bookings" ON bookings FOR SELECT USING (true);
CREATE POLICY "Allow public insert access to bookings" ON bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update access to bookings" ON bookings FOR UPDATE USING (true);
CREATE POLICY "Allow public delete access to bookings" ON bookings FOR DELETE USING (true);
`;async function C(){let a={email_configurations:!1,email_templates:!1,email_triggers:!1,email_logs:!1,bookings:!1};if(!v.supabase)return a;try{let{data:b}=await v.supabase.from(v.CG.EMAIL_CONFIGURATIONS).select("id").limit(1);a.email_configurations=!!b;let{data:c}=await v.supabase.from(v.CG.EMAIL_TEMPLATES).select("id").limit(1);a.email_templates=!!c;let{data:d}=await v.supabase.from(v.CG.EMAIL_TRIGGERS).select("id").limit(1);a.email_triggers=!!d;let{data:e}=await v.supabase.from(v.CG.EMAIL_LOGS).select("id").limit(1);a.email_logs=!!e;let{data:f}=await v.supabase.from(v.CG.BOOKINGS).select("id").limit(1);a.bookings=!!f}catch(a){console.error("Error checking email tables:",a)}return a}async function D(){try{let a=await C();return u.NextResponse.json({success:!0,message:"Email database status checked",tables:a,allTablesExist:Object.values(a).every(a=>a),sqlScript:B})}catch(a){return console.error("Error checking email database:",a),u.NextResponse.json({success:!1,message:"Error checking email database",error:a instanceof Error?a.message:"Unknown error"},{status:500})}}async function E(){try{let a=await w();return u.NextResponse.json({success:a.success,message:a.message,tablesCreated:a.tablesCreated,errors:a.errors})}catch(a){return console.error("Error setting up email database:",a),u.NextResponse.json({success:!1,message:"Error setting up email database",error:a instanceof Error?a.message:"Unknown error"},{status:500})}}let F=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/email/setup-database/route",pathname:"/api/email/setup-database",filename:"route",bundlePath:"app/api/email/setup-database/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/ishaankhan/Desktop/Luxe/luxe-app/src/app/api/email/setup-database/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:G,workUnitAsyncStorage:H,serverHooks:I}=F;function J(){return(0,g.patchFetch)({workAsyncStorage:G,workUnitAsyncStorage:H})}async function K(a,b,c){var d;let e="/api/email/setup-database/route";"/index"===e&&(e="/");let g=await F.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,resolvedPathname:C}=g,D=(0,j.normalizeAppPath)(e),E=!!(y.dynamicRoutes[D]||y.routes[C]);if(E&&!x){let a=!!y.routes[C],b=y.dynamicRoutes[D];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!E||F.isDev||x||(G="/index"===(G=C)?"/":G);let H=!0===F.isDev||!E,I=E&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>F.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>F.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&A&&B&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!E)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await F.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})},z),b}},l=await F.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:A,revalidateOnlyGenerated:B,responseGenerator:k,waitUntil:c.waitUntil});if(!E)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",A?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&E||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await F.onRequestError(a,b,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:A})}),E)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},88908:(a,b,c)=>{"use strict";c.d(b,{AG:()=>f,CG:()=>g,supabase:()=>e});class d{static getInstance(){return d.instance||(d.instance=new d),d.instance}async initialize(){return Promise.resolve()}getClient(){return this.client}from(a){let b={select:a=>b,insert:a=>b,update:a=>b,delete:()=>b,eq:(a,c)=>b,in:(a,c)=>b,gte:(a,c)=>b,lte:(a,c)=>b,order:(a,c)=>b,limit:a=>b,then:a=>a({data:[],error:null})};return b}async auth(){return{getUser:()=>Promise.resolve({data:{user:null},error:null}),signIn:()=>Promise.resolve({data:{user:null},error:null}),signOut:()=>Promise.resolve({error:null})}}async rpc(a,b){return Promise.resolve({data:null,error:null})}constructor(){this.client=null}}let e=d.getInstance(),f=()=>e.getClient(),g={PROPERTIES:"properties",BOOKINGS:"bookings",USERS:"users",DESTINATIONS:"destinations",DEAL_BANNERS:"deal_banners",HERO_BACKGROUNDS:"hero_backgrounds",CALLBACKS:"callbacks",CONTACTS:"contacts",CONSULTATIONS:"consultations",PARTNERS:"partners",PAYMENTS:"payments",LOYALTY_RULES:"loyalty_rules",LOYALTY_REDEMPTIONS:"loyalty_redemptions",EMAIL_TEMPLATES:"email_templates",EMAIL_TRIGGERS:"email_triggers",EMAIL_CONFIGURATIONS:"email_configurations",EMAIL_LOGS:"email_logs",WHATSAPP_MESSAGES:"whatsapp_messages",INSTAGRAM_POSTS:"instagram_posts"}},96487:()=>{}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[4586,1692],()=>b(b.s=34115));module.exports=c})();