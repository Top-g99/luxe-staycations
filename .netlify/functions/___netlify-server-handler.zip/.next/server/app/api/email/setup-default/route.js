(()=>{var a={};a.id=9024,a.ids=[8908,9024],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61478:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>C,patchFetch:()=>B,routeModule:()=>x,serverHooks:()=>A,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>z});var d={};c.r(d),c.d(d,{POST:()=>w});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(88908);async function w(a){try{let a=(0,v.AG)(),b={configurations:0,templates:0,errors:[]};try{if(!a)return u.NextResponse.json({error:"Supabase client not available"},{status:500});let{data:c}=await a.from("email_configurations").select("id").limit(1);if(!c||0===c.length){let{error:c}=await a.from("email_configurations").insert([{smtp_host:"smtp.gmail.com",smtp_port:587,smtp_user:"your-email@gmail.com",smtp_password:"your-app-password",enable_ssl:!1,from_name:"Luxe Staycations",from_email:"info@luxestaycations.in",is_active:!1,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}]);c?b.errors.push(`Configuration setup failed: ${c.message}`):b.configurations=1}}catch(a){b.errors.push(`Configuration error: ${a instanceof Error?a.message:"Unknown error"}`)}try{if(!a)return u.NextResponse.json({error:"Supabase client not available"},{status:500});let{data:c}=await a.from("email_templates").select("id").limit(1);if(!c||0===c.length){let c=[{name:"Booking Confirmation",type:"booking_confirmation",subject:"\uD83C\uDF89 Booking Confirmed - {{bookingId}} | Luxe Staycations",html_content:`
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <title>Booking Confirmation</title>
              </head>
              <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background: linear-gradient(135deg, #8B4513, #000); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                  <h1 style="margin: 0; font-size: 28px;">🎉 Booking Confirmed!</h1>
                  <p style="margin: 10px 0 0 0; font-size: 16px;">Thank you for choosing Luxe Staycations</p>
                </div>
                
                <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
                  <h2 style="color: #8B4513; margin-top: 0;">Booking Details</h2>
                  <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Booking ID:</strong> {{bookingId}}</p>
                    <p><strong>Property:</strong> {{propertyName}}</p>
                    <p><strong>Location:</strong> {{propertyLocation}}</p>
                    <p><strong>Check-in:</strong> {{checkIn}}</p>
                    <p><strong>Check-out:</strong> {{checkOut}}</p>
                    <p><strong>Guests:</strong> {{guests}}</p>
                    <p><strong>Total Amount:</strong> {{totalAmount}}</p>
                  </div>
                  
                  <h3 style="color: #8B4513;">What's Next?</h3>
                  <ul>
                    <li>You will receive a detailed itinerary 24 hours before your check-in</li>
                    <li>Our team will contact you to confirm your arrival time</li>
                    <li>Any special requests will be arranged prior to your stay</li>
                  </ul>
                  
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="mailto:info@luxestaycations.in" style="background: #8B4513; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">Contact Us</a>
                  </div>
                </div>
                
                <div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">
                  <p>Luxe Staycations - Premium Villa Rentals</p>
                  <p>Email: info@luxestaycations.in | Phone: +91-8828279739</p>
                </div>
              </body>
              </html>
            `,text_content:`Booking Confirmed - {{bookingId}}

Dear {{guestName}},

Thank you for choosing Luxe Staycations! Your booking has been confirmed.

Booking Details:
- Booking ID: {{bookingId}}
- Property: {{propertyName}}
- Location: {{propertyLocation}}
- Check-in: {{checkIn}}
- Check-out: {{checkOut}}
- Guests: {{guests}}
- Total Amount: {{totalAmount}}

What's Next?
- You will receive a detailed itinerary 24 hours before your check-in
- Our team will contact you to confirm your arrival time
- Any special requests will be arranged prior to your stay

Contact us at info@luxestaycations.in or +91-8828279739

Best regards,
Luxe Staycations Team`,variables:["guestName","bookingId","propertyName","propertyLocation","checkIn","checkOut","guests","totalAmount"],is_active:!0,is_default:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{name:"Contact Form Thank You",type:"contact_form",subject:"\uD83D\uDE4F Thank You for Contacting Us - {{subject}} | Luxe Staycations",html_content:`
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <title>Thank You for Contacting Us</title>
              </head>
              <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background: linear-gradient(135deg, #8B4513, #000); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                  <h1 style="margin: 0; font-size: 28px;">🙏 Thank You for Contacting Us!</h1>
                  <p style="margin: 10px 0 0 0; font-size: 16px;">We appreciate your interest in Luxe Staycations</p>
                </div>
                
                <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
                  <h2 style="color: #8B4513; margin-top: 0;">Your Message Details</h2>
                  <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Name:</strong> {{name}}</p>
                    <p><strong>Email:</strong> {{email}}</p>
                    <p><strong>Phone:</strong> {{phone}}</p>
                    <p><strong>Subject:</strong> {{subject}}</p>
                    <p><strong>Message:</strong></p>
                    <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin-top: 10px; white-space: pre-wrap;">{{message}}</div>
                  </div>
                  
                  <h3 style="color: #8B4513;">What Happens Next?</h3>
                  <ul style="margin: 20px 0; padding-left: 20px;">
                    <li>Our travel specialists will review your inquiry within 24 hours</li>
                    <li>We will contact you to discuss your travel preferences and villa requirements</li>
                    <li>We will provide personalized recommendations based on your needs</li>
                    <li>We will assist you in finding the perfect villa for your stay</li>
                    <li>We will help you plan your entire travel experience</li>
                  </ul>
                  
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="mailto:info@luxestaycations.in" style="background: #8B4513; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;">Contact Our Travel Specialists</a>
                    <a href="https://luxestaycations.in/villas" style="background: #000; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;">Browse Our Villas</a>
                  </div>
                </div>
                
                <div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">
                  <p>Luxe Staycations - Premium Villa Rentals & Travel Planning</p>
                  <p>Email: info@luxestaycations.in | Phone: +91-8828279739</p>
                </div>
              </body>
              </html>
            `,text_content:`Thank You for Contacting Us - {{subject}}

Dear {{name}},

Thank you for reaching out to Luxe Staycations! We appreciate your interest in our luxury villa rentals and travel planning services.

Your Message Details:
- Name: {{name}}
- Email: {{email}}
- Phone: {{phone}}
- Subject: {{subject}}
- Message: {{message}}

What Happens Next?
- Our travel specialists will review your inquiry within 24 hours
- We will contact you to discuss your travel preferences and villa requirements
- We will provide personalized recommendations based on your needs
- We will assist you in finding the perfect villa for your stay
- We will help you plan your entire travel experience

Contact our travel specialists at info@luxestaycations.in
Browse our villas at https://luxestaycations.in/villas

Best regards,
Luxe Staycations Travel Team

Email: info@luxestaycations.in | Phone: +91-8828279739`,variables:["name","email","phone","subject","message"],is_active:!0,is_default:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{name:"Consultation Request",type:"consultation_request",subject:"\uD83C\uDFE1 Host Partnership Consultation Confirmed - {{requestId}} | Luxe Staycations",html_content:`
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <title>Host Partnership Consultation Confirmation</title>
              </head>
              <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="background: linear-gradient(135deg, #8B4513, #000); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                  <h1 style="margin: 0; font-size: 28px;">🏡 Host Partnership Consultation Confirmed!</h1>
                  <p style="margin: 10px 0 0 0; font-size: 16px;">Welcome to the Luxe Staycations Host Family</p>
                </div>
                
                <div style="background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px;">
                  <h2 style="color: #8B4513; margin-top: 0;">Partnership Consultation Details</h2>
                  <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Request ID:</strong> {{requestId}}</p>
                    <p><strong>Name:</strong> {{name}}</p>
                    <p><strong>Email:</strong> {{email}}</p>
                    <p><strong>Phone:</strong> {{phone}}</p>
                    <p><strong>Property Type:</strong> {{propertyType}}</p>
                    <p><strong>Location:</strong> {{location}}</p>
                    <p><strong>Preferred Date:</strong> {{preferredDate}}</p>
                    <p><strong>Preferred Time:</strong> {{preferredTime}}</p>
                    <p><strong>Consultation Type:</strong> {{consultationType}}</p>
                  </div>
                  
                  <h3 style="color: #8B4513;">What Happens Next?</h3>
                  <ul style="margin: 20px 0; padding-left: 20px;">
                    <li>Our partnership specialist will contact you within 24 hours</li>
                    <li>We will conduct a detailed property assessment and market analysis</li>
                    <li>We will discuss partnership terms, commission structure, and revenue projections</li>
                    <li>We will guide you through the onboarding process and property preparation</li>
                    <li>We will create a customized marketing strategy for your property</li>
                  </ul>
                  
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="mailto:partnerships@luxestaycations.in" style="background: #8B4513; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;">Contact Our Partnership Team</a>
                    <a href="https://luxestaycations.in/partner-with-us" style="background: #000; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;">Learn More About Hosting</a>
                  </div>
                </div>
                
                <div style="text-align: center; margin-top: 20px; color: #666; font-size: 14px;">
                  <p>Luxe Staycations - Premium Villa Rentals & Host Partnership Program</p>
                  <p>Email: info@luxestaycations.in | Phone: +91-8828279739</p>
                </div>
              </body>
              </html>
            `,text_content:`Host Partnership Consultation Confirmed - {{requestId}}

Dear {{name}},

Welcome to the Luxe Staycations Host Family! Thank you for your interest in partnering with us as a property owner.

Partnership Consultation Details:
- Request ID: {{requestId}}
- Name: {{name}}
- Email: {{email}}
- Phone: {{phone}}
- Property Type: {{propertyType}}
- Location: {{location}}
- Preferred Date: {{preferredDate}}
- Preferred Time: {{preferredTime}}
- Consultation Type: {{consultationType}}

What Happens Next?
- Our partnership specialist will contact you within 24 hours
- We will conduct a detailed property assessment and market analysis
- We will discuss partnership terms, commission structure, and revenue projections
- We will guide you through the onboarding process and property preparation
- We will create a customized marketing strategy for your property

Contact our partnerships team at partnerships@luxestaycations.in
Visit our hosting page: https://luxestaycations.in/partner-with-us

Best regards,
Luxe Staycations Partnership Team`,variables:["requestId","name","email","phone","propertyType","location","preferredDate","preferredTime","consultationType"],is_active:!0,is_default:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}],{error:d}=await a.from("email_templates").insert(c);d?b.errors.push(`Template setup failed: ${d.message}`):b.templates=c.length}}catch(a){b.errors.push(`Template error: ${a instanceof Error?a.message:"Unknown error"}`)}return u.NextResponse.json({success:0===b.errors.length,message:`Setup completed: ${b.configurations} configurations, ${b.templates} templates created`,results:b})}catch(a){return console.error("Email setup failed:",a),u.NextResponse.json({success:!1,message:`Setup failed: ${a instanceof Error?a.message:"Unknown error"}`},{status:500})}}let x=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/email/setup-default/route",pathname:"/api/email/setup-default",filename:"route",bundlePath:"app/api/email/setup-default/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/Users/ishaankhan/Desktop/Luxe/luxe-app/src/app/api/email/setup-default/route.ts",nextConfigOutput:"standalone",userland:d}),{workAsyncStorage:y,workUnitAsyncStorage:z,serverHooks:A}=x;function B(){return(0,g.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:z})}async function C(a,b,c){var d;let e="/api/email/setup-default/route";"/index"===e&&(e="/");let g=await x.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:y,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!y){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||x.isDev||y||(G="/index"===(G=D)?"/":G);let H=!0===x.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>x.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>x.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await x.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await x.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await x.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},88908:(a,b,c)=>{"use strict";c.d(b,{AG:()=>f,CG:()=>g,supabase:()=>e});class d{static getInstance(){return d.instance||(d.instance=new d),d.instance}async initialize(){return Promise.resolve()}getClient(){return this.client}from(a){let b={select:a=>b,insert:a=>b,update:a=>b,delete:()=>b,eq:(a,c)=>b,in:(a,c)=>b,gte:(a,c)=>b,lte:(a,c)=>b,order:(a,c)=>b,limit:a=>b,then:a=>a({data:[],error:null})};return b}async auth(){return{getUser:()=>Promise.resolve({data:{user:null},error:null}),signIn:()=>Promise.resolve({data:{user:null},error:null}),signOut:()=>Promise.resolve({error:null})}}async rpc(a,b){return Promise.resolve({data:null,error:null})}constructor(){this.client=null}}let e=d.getInstance(),f=()=>e.getClient(),g={PROPERTIES:"properties",BOOKINGS:"bookings",USERS:"users",DESTINATIONS:"destinations",DEAL_BANNERS:"deal_banners",HERO_BACKGROUNDS:"hero_backgrounds",CALLBACKS:"callbacks",CONTACTS:"contacts",CONSULTATIONS:"consultations",PARTNERS:"partners",PAYMENTS:"payments",LOYALTY_RULES:"loyalty_rules",LOYALTY_REDEMPTIONS:"loyalty_redemptions",EMAIL_TEMPLATES:"email_templates",EMAIL_TRIGGERS:"email_triggers",EMAIL_CONFIGURATIONS:"email_configurations",EMAIL_LOGS:"email_logs",WHATSAPP_MESSAGES:"whatsapp_messages",INSTAGRAM_POSTS:"instagram_posts"}},96487:()=>{}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[4586,1692],()=>b(b.s=61478));module.exports=c})();