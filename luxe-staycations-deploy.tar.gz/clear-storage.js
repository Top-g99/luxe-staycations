// Clear all Luxe data from localStorage
localStorage.clear();
console.log('All localStorage data cleared!');
