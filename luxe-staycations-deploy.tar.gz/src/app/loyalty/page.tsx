"use client";

import React from 'react';
import LoyaltyDashboard from '@/components/loyalty/LoyaltyDashboard';

export default function LoyaltyPage() {
  return <LoyaltyDashboard />;
}

