'use client';

import React from 'react';
import {
  Box,
  TextField,
  Grid,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextareaAutosize
} from '@mui/material';
import { Person, Email, Phone, LocationOn, Message } from '@mui/icons-material';

interface GuestInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address?: string;
  city?: string;
  country?: string;
  specialRequests?: string;
}

interface GuestInfoFormProps {
  guestInfo: GuestInfo;
  onGuestInfoChange: (field: string, value: string) => void;
}

export default function GuestInfoForm({ guestInfo, onGuestInfoChange }: GuestInfoFormProps) {
  const countries = [
    'India', 'United States', 'United Kingdom', 'Canada', 'Australia', 
    'Germany', 'France', 'Japan', 'Singapore', 'United Arab Emirates',
    'Saudi Arabia', 'Qatar', 'Kuwait', 'Oman', 'Bahrain'
  ];

  const cities = [
    'Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Kolkata',
    'Pune', 'Ahmedabad', 'Jaipur', 'Surat', 'Lucknow', 'Kanpur',
    'Nagpur', 'Indore', 'Thane', 'Bhopal', 'Visakhapatnam', 'Pimpri-Chinchwad',
    'Patna', 'Vadodara', 'Ghaziabad', 'Ludhiana', 'Agra', 'Nashik',
    'Faridabad', 'Meerut', 'Rajkot', 'Kalyan-Dombivali', 'Vasai-Virar',
    'Varanasi', 'Srinagar', 'Aurangabad', 'Dhanbad', 'Amritsar',
    'Allahabad', 'Ranchi', 'Howrah', 'Coimbatore', 'Jabalpur',
    'Gwalior', 'Vijayawada', 'Jodhpur', 'Madurai', 'Raipur',
    'Kota', 'Guwahati', 'Chandigarh', 'Solapur', 'Hubli-Dharwad',
    'Bareilly', 'Moradabad', 'Mysore', 'Gurgaon', 'Aligarh',
    'Jalandhar', 'Tiruchirappalli', 'Bhubaneswar', 'Salem', 'Warangal',
    'Mira-Bhayandar', 'Thiruvananthapuram', 'Bhiwandi', 'Saharanpur',
    'Gorakhpur', 'Guntur', 'Bikaner', 'Amravati', 'Noida', 'Jamshedpur',
    'Bhilai', 'Cuttack', 'Firozabad', 'Kochi', 'Nellore', 'Bhavnagar',
    'Dehradun', 'Durgapur', 'Asansol', 'Rourkela', 'Nanded', 'Kolhapur',
    'Ajmer', 'Akola', 'Gulbarga', 'Jamnagar', 'Ujjain', 'Loni',
    'Siliguri', 'Jhansi', 'Ulhasnagar', 'Jammu', 'Sangli-Miraj',
    'Mangalore', 'Erode', 'Belgaum', 'Ambattur', 'Tirunelveli',
    'Malegaon', 'Gaya', 'Jalgaon', 'Udaipur', 'Maheshtala'
  ];

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h6" sx={{ mb: 3, fontWeight: 600, color: '#5a3d35' }}>
        Guest Information
      </Typography>
      
      <Grid container spacing={3}>
        {/* Personal Information */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600, color: '#d97706' }}>
            Personal Details
          </Typography>
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="First Name *"
            value={guestInfo.firstName}
            onChange={(e) => onGuestInfoChange('firstName', e.target.value)}
            required
            InputProps={{
              startAdornment: <Person sx={{ color: 'text.secondary', mr: 1 }} />
            }}
          />
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Last Name *"
            value={guestInfo.lastName}
            onChange={(e) => onGuestInfoChange('lastName', e.target.value)}
            required
            InputProps={{
              startAdornment: <Person sx={{ color: 'text.secondary', mr: 1 }} />
            }}
          />
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Email Address *"
            type="email"
            value={guestInfo.email}
            onChange={(e) => onGuestInfoChange('email', e.target.value)}
            required
            InputProps={{
              startAdornment: <Email sx={{ color: 'text.secondary', mr: 1 }} />
            }}
          />
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Phone Number *"
            value={guestInfo.phone}
            onChange={(e) => onGuestInfoChange('phone', e.target.value)}
            required
            InputProps={{
              startAdornment: <Phone sx={{ color: 'text.secondary', mr: 1 }} />
            }}
          />
        </Grid>

        {/* Address Information */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ mb: 2, mt: 2, fontWeight: 600, color: '#d97706' }}>
            Address Information
          </Typography>
        </Grid>
        
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Address"
            value={guestInfo.address || ''}
            onChange={(e) => onGuestInfoChange('address', e.target.value)}
            multiline
            rows={2}
            InputProps={{
              startAdornment: <LocationOn sx={{ color: 'text.secondary', mr: 1, mt: 1 }} />
            }}
          />
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth>
            <InputLabel>City</InputLabel>
            <Select
              value={guestInfo.city || ''}
              onChange={(e) => onGuestInfoChange('city', e.target.value)}
              label="City"
            >
              <MenuItem value="">Select a city</MenuItem>
              {cities.map((city) => (
                <MenuItem key={city} value={city}>{city}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        
        <Grid item xs={12} sm={6}>
          <FormControl fullWidth>
            <InputLabel>Country</InputLabel>
            <Select
              value={guestInfo.country || ''}
              onChange={(e) => onGuestInfoChange('country', e.target.value)}
              label="Country"
            >
              <MenuItem value="">Select a country</MenuItem>
              {countries.map((country) => (
                <MenuItem key={country} value={country}>{country}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>

        {/* Special Requests */}
        <Grid item xs={12}>
          <Typography variant="subtitle1" sx={{ mb: 2, mt: 2, fontWeight: 600, color: '#d97706' }}>
            Special Requests
          </Typography>
        </Grid>
        
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Special Requests or Preferences"
            value={guestInfo.specialRequests || ''}
            onChange={(e) => onGuestInfoChange('specialRequests', e.target.value)}
            multiline
            rows={3}
            placeholder="Any special requests, dietary preferences, accessibility needs, or other requirements..."
            InputProps={{
              startAdornment: <Message sx={{ color: 'text.secondary', mr: 1, mt: 1 }} />
            }}
          />
        </Grid>
      </Grid>
    </Box>
  );
}


