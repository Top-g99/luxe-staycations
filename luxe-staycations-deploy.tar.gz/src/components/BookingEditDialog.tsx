'use client';

import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Box,
  Alert,
  FormControlLabel,
  Switch
} from '@mui/material';
import { Edit, Save, Cancel } from '@mui/icons-material';
import { Booking, bookingManager } from '@/lib/bookingManager';

interface BookingEditDialogProps {
  open: boolean;
  onClose: () => void;
  booking: Booking | null;
  mode: 'create' | 'edit';
}

export default function BookingEditDialog({ open, onClose, booking, mode }: BookingEditDialogProps) {
  const [formData, setFormData] = useState<Partial<Booking>>({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    propertyId: '',
    propertyName: '',
    checkIn: '',
    checkOut: '',
    guests: 1,
    amount: 0,
    status: 'pending'
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (booking && mode === 'edit') {
      setFormData(booking);
    } else {
      setFormData({
        guestName: '',
        guestEmail: '',
        guestPhone: '',
        propertyId: '',
        propertyName: '',
        checkIn: '',
        checkOut: '',
        guests: 1,
        amount: 0,
        status: 'pending'
      });
    }
    setError('');
    setSuccess('');
  }, [booking, mode, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async () => {
    try {
      if (!formData.guestName || !formData.guestEmail || !formData.propertyId || !formData.checkIn || !formData.checkOut || !formData.amount) {
        setError('Please fill in all required fields');
        return;
      }

      if (mode === 'edit' && booking) {
        // Update existing booking
        const success = bookingManager.updateBooking(booking.id, formData);
        if (success) {
          setSuccess('Booking updated successfully');
          setTimeout(() => {
            onClose();
          }, 1500);
        } else {
          setError('Failed to update booking');
        }
      } else {
        // Create new booking
        const newBooking = bookingManager.addBooking({
          guestName: formData.guestName!,
          guestEmail: formData.guestEmail!,
          guestPhone: formData.guestPhone || '',
          propertyId: formData.propertyId!,
          propertyName: formData.propertyName || '',
          checkIn: formData.checkIn!,
          checkOut: formData.checkOut!,
          guests: formData.guests || 1,
          amount: formData.amount!,
          status: formData.status || 'pending'
        });
        
        setSuccess('Booking created successfully');
        setTimeout(() => {
          onClose();
        }, 1500);
      }
    } catch (error) {
      console.error('Error saving booking:', error);
      setError('Error saving booking. Please try again.');
    }
  };

  const handleClose = () => {
    setError('');
    setSuccess('');
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Edit />
        {mode === 'edit' ? 'Edit Booking' : 'Create New Booking'}
      </DialogTitle>
      
      <DialogContent>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        
        {success && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {success}
          </Alert>
        )}

        <Grid container spacing={3} sx={{ mt: 1 }}>
          {/* Guest Information */}
          <Grid item xs={12}>
            <Typography variant="h6" sx={{ mb: 2, color: '#d97706' }}>
              Guest Information
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Guest Name *"
              value={formData.guestName || ''}
              onChange={(e) => handleChange('guestName', e.target.value)}
              required
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Guest Email *"
              type="email"
              value={formData.guestEmail || ''}
              onChange={(e) => handleChange('guestEmail', e.target.value)}
              required
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Guest Phone"
              value={formData.guestPhone || ''}
              onChange={(e) => handleChange('guestPhone', e.target.value)}
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Number of Guests *"
              type="number"
              value={formData.guests || 1}
              onChange={(e) => handleChange('guests', parseInt(e.target.value))}
              required
            />
          </Grid>

          {/* Property Information */}
          <Grid item xs={12}>
            <Typography variant="h6" sx={{ mb: 2, color: '#d97706', mt: 2 }}>
              Property Information
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Property ID *"
              value={formData.propertyId || ''}
              onChange={(e) => handleChange('propertyId', e.target.value)}
              required
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Property Name"
              value={formData.propertyName || ''}
              onChange={(e) => handleChange('propertyName', e.target.value)}
            />
          </Grid>
          


          {/* Booking Details */}
          <Grid item xs={12}>
            <Typography variant="h6" sx={{ mb: 2, color: '#d97706', mt: 2 }}>
              Booking Details
            </Typography>
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Check-in Date *"
              type="date"
              value={formData.checkIn || ''}
              onChange={(e) => handleChange('checkIn', e.target.value)}
              required
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Check-out Date *"
              type="date"
              value={formData.checkOut || ''}
              onChange={(e) => handleChange('checkOut', e.target.value)}
              required
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Total Amount *"
              type="number"
              value={formData.amount || 0}
              onChange={(e) => handleChange('amount', parseFloat(e.target.value))}
              required
            />
          </Grid>
          
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>Status</InputLabel>
              <Select
                value={formData.status || 'pending'}
                onChange={(e) => handleChange('status', e.target.value)}
                label="Status"
              >
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="confirmed">Confirmed</MenuItem>
                <MenuItem value="cancelled">Cancelled</MenuItem>
                <MenuItem value="completed">Completed</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          

        </Grid>
      </DialogContent>
      
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={handleClose} startIcon={<Cancel />}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          startIcon={<Save />}
          sx={{
            background: 'linear-gradient(45deg, #5a3d35, #d97706)',
            '&:hover': {
              background: 'linear-gradient(45deg, #4a332c, #b45309)',
            }
          }}
        >
          {mode === 'edit' ? 'Update Booking' : 'Create Booking'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

